<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Math Quiz App</title>
  <link href="./output.css" rel="stylesheet" />
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

  <div class="bg-white p-6 rounded-2xl shadow-lg w-full max-w-md">
    <h1 class="text-xl font-bold mb-4 text-center">🧠 <span id="topicTitle">Math Quiz</span></h1>

    <!-- Timer -->
    <div class="text-sm text-right text-gray-500 mb-2">⏳ Time: <span id="timer">10</span>s</div>

    <!-- Question -->
    <div id="questionBox" class="text-lg font-medium mb-4"></div>

    <!-- Answer -->
    <input id="answerInput" type="text" class="w-full px-4 py-2 border rounded-xl mb-4" placeholder="Enter your answer" />

    <!-- Submit -->
    <button id="nextBtn" class="w-full bg-blue-600 text-white py-2 rounded-xl hover:bg-blue-700">
      Submit Answer
    </button>

    <!-- Feedback -->
    <div id="resultBox" class="mt-4 text-sm font-medium hidden cursor-pointer"></div>

    <!-- Summary -->
    <div id="summaryBox" class="mt-4 hidden text-center"></div>

    <!-- Next Topic -->
    <div class="mt-4 text-center">
      <button id="nextTopicBtn" class="hidden bg-green-600 text-white px-4 py-2 rounded-xl hover:bg-green-700">
        ➡️ Next Topic
      </button>
    </div>

    <!-- Restart -->
    <div class="mt-4 text-center">
      <button id="restartBtn" class="hidden bg-red-500 text-white px-4 py-2 rounded-xl hover:bg-red-600">
        🔄 Restart Quiz
      </button>
    </div>
  </div>

  <script>
    const topics = {
      "Math Quiz": [
        { question: "What is 5 + 3?", answer: "8" },
        { question: "What is 10 - 4?", answer: "6" },
        { question: "What is 6 x 2?", answer: "12" },
        { question: "What is 12 ÷ 3?", answer: "4" }
      ],
      "Shapes Match": [
        { question: "A shape with 3 sides is called?", answer: "triangle" },
        { question: "A shape with 4 equal sides and angles?", answer: "square" },
        { question: "A shape that looks like a ball?", answer: "circle" },
        { question: "A shape with 5 sides?", answer: "pentagon" }
      ]
    };

    const topicKeys = Object.keys(topics);
    let currentTopicIndex = 0;
    let questions = [];
    let currentIndex = 0;
    let score = 0;
    let timer, timeLeft = 10;
    let startTime = new Date();

    // DOM elements
    const topicTitle = document.getElementById("topicTitle");
    const questionBox = document.getElementById("questionBox");
    const answerInput = document.getElementById("answerInput");
    const nextBtn = document.getElementById("nextBtn");
    const resultBox = document.getElementById("resultBox");
    const summaryBox = document.getElementById("summaryBox");
    const timerDisplay = document.getElementById("timer");
    const restartBtn = document.getElementById("restartBtn");
    const nextTopicBtn = document.getElementById("nextTopicBtn");

    // Shuffle helper
    function shuffleArray(arr) {
      return arr.sort(() => Math.random() - 0.5);
    }

    function startTimer() {
      timeLeft = 10;
      timerDisplay.textContent = timeLeft;
      clearInterval(timer);
      timer = setInterval(() => {
        timeLeft--;
        timerDisplay.textContent = timeLeft;
        if (timeLeft === 0) {
          clearInterval(timer);
          showResult("⏰ Time's up! Click to retry.", "text-red-600");
        }
      }, 1000);
    }

    function stopTimer() {
      clearInterval(timer);
    }

    function showQuestion() {
      if (currentIndex < questions.length) {
        questionBox.textContent = questions[currentIndex].question;
        answerInput.value = "";
        resultBox.classList.add("hidden");
        summaryBox.classList.add("hidden");
        nextTopicBtn.classList.add("hidden");
        startTimer();
      } else {
        stopTimer();
        showSummary();
      }
    }

    function showResult(message, colorClass) {
      resultBox.textContent = message;
      resultBox.className = `mt-4 text-sm font-medium ${colorClass} cursor-pointer`;
      resultBox.classList.remove("hidden");
    }

    function showSummary() {
      const percentage = Math.round((score / questions.length) * 100);
      summaryBox.innerHTML = `
        <h2 class="text-lg font-semibold text-green-600">🎉 Topic Completed!</h2>
        <p class="mt-2">You got <strong>${score}</strong> out of <strong>${questions.length}</strong>.</p>
        <p>Your score: <strong>${percentage}%</strong></p>
      `;
      summaryBox.classList.remove("hidden");

      // Save session data to DB
      saveSession();

      if (currentTopicIndex + 1 < topicKeys.length) {
        nextTopicBtn.classList.remove("hidden");
      } else {
        questionBox.textContent = "🏁 All topics completed!";
        answerInput.style.display = "none";
        nextBtn.disabled = true;
        nextBtn.classList.add("bg-gray-400", "cursor-not-allowed");
        restartBtn.classList.remove("hidden");
      }
    }

    function loadTopic(index) {
      currentTopicIndex = index;
      const topic = topicKeys[currentTopicIndex];
      topicTitle.textContent = topic;
      questions = shuffleArray([...topics[topic]]);
      currentIndex = 0;
      score = 0;
      answerInput.style.display = "block";
      nextBtn.disabled = false;
      nextBtn.classList.remove("bg-gray-400", "cursor-not-allowed");
      showQuestion();
      startTime = new Date(); // reset start time for new topic
    }

    function saveSession() {
      const endTime = new Date();
      const durationSeconds = Math.floor((endTime - startTime) / 1000);
      const topic = topicKeys[currentTopicIndex];

      fetch('save_session.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic_name: topic,
          start_time: startTime.toISOString(),
          end_time: endTime.toISOString(),
          duration_seconds: durationSeconds,
          score: score,
          total_questions: questions.length
        })
      })
      .then(res => res.json())
      .then(data => console.log("Session saved:", data))
      .catch(err => console.error("Save failed:", err));
    }

    nextBtn.addEventListener("click", () => {
      const userAnswer = answerInput.value.trim().toLowerCase();
      const correctAnswer = questions[currentIndex].answer.toLowerCase();

      if (userAnswer === "") {
        showResult("⚠️ Please enter an answer.", "text-yellow-600");
        return;
      }

      if (userAnswer === correctAnswer) {
        stopTimer();
        showResult("✔️ Correct!", "text-green-600");
        score++;
        currentIndex++;
        setTimeout(showQuestion, 1000);
      } else {
        stopTimer();
        showResult("❌ Try again! Click here to retry.", "text-red-600");
      }
    });

    resultBox.addEventListener("click", () => {
      if (resultBox.textContent.includes("Try again") || resultBox.textContent.includes("Time's up")) {
        resultBox.classList.add("hidden");
        answerInput.value = "";
        answerInput.focus();
        startTimer();
      }
    });

    nextTopicBtn.addEventListener("click", () => {
      loadTopic(currentTopicIndex + 1);
    });

    restartBtn.addEventListener("click", () => {
      currentTopicIndex = 0;
      loadTopic(currentTopicIndex);
      restartBtn.classList.add("hidden");
    });

    // Start the first topic
    loadTopic(currentTopicIndex);
  </script>

</body>
</html>
