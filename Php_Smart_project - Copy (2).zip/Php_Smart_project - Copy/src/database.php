<!-- <?php
// $db_server = "localhost";
// $db_username = "root";
// $db_password = "";
// $db_database = "login_register";

// $conn = mysqli_connect(
//     $db_server,
//     $db_username,
//     $db_password,
//     $db_database);

// if($conn){
//     echo "Your connected";
// }
// else{
//     echo "your are not connected";
// }
?>

 -->

<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'login_register');

// Start session
session_start();

// Establish database connection
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Redirect function
function redirect($url) {
    header("Location: $url");
    exit();
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}
?>
