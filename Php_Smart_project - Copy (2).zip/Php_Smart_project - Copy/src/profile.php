<?php
// profile.php

session_start();

// If user not logged in, redirect to login
if (!isset($_SESSION['user_id'])) {
    header('Location: Login.php');
    exit;
}

// Connect to DB
$conn = mysqli_connect('localhost', 'root', '', 'login_register');
if (!$conn) {
    die('Database connection failed.');
}

// Get user data
$user_id = $_SESSION['user_id'];
$sql = "SELECT fullname, username FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $fullname, $username);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>User Profile</title>
  <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
  <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-md">
    <h2 class="text-2xl font-bold text-blue-600 mb-4">Your Profile</h2>
    <div class="mb-4">
      <strong>Full Name:</strong> <?= htmlspecialchars($fullname) ?>
    </div>
    <div class="mb-4">
      <strong>Username:</strong> <?= htmlspecialchars($username) ?>
    </div>
    <a href="logout.php" class="text-red-600 hover:underline">Logout</a>
  </div>
</body>
</html>
