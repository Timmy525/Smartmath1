<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: Login.php');
    exit;
}

$conn = mysqli_connect('localhost', 'root', '', 'login_register');
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM quiz_sessions WHERE user_id = ? ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Quiz Sessions</title>
  <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-50 p-8">
  <div class="max-w-4xl mx-auto bg-white shadow rounded-lg p-6">
    <h2 class="text-2xl font-bold mb-4 text-blue-700">📊 Quiz History</h2>
    <table class="w-full table-auto border-collapse text-sm">
      <thead class="bg-blue-100">
        <tr>
          <th class="border px-4 py-2">Start Time</th>
          <th class="border px-4 py-2">End Time</th>
          <th class="border px-4 py-2">Duration (s)</th>
          <th class="border px-4 py-2" colspan="2">Score Progress</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) :
          $percentage = $row['total_questions'] > 0
            ? round(($row['score'] / $row['total_questions']) * 100)
            : 0;
        ?>
          <tr class="text-center">
            <td class="border px-4 py-2"><?= htmlspecialchars($row['start_time']) ?></td>
            <td class="border px-4 py-2"><?= htmlspecialchars($row['end_time']) ?></td>
            <td class="border px-4 py-2"><?= htmlspecialchars($row['duration_seconds']) ?></td>
            <td class="border px-4 py-2" colspan="2">
              <div class="w-full bg-gray-200 rounded-full h-4 relative">
                <div class="bg-blue-500 h-4 rounded-full" style="width: <?= $percentage ?>%"></div>
                <span class="absolute inset-0 flex justify-center items-center text-xs text-white font-bold">
                  <?= htmlspecialchars($row['score']) ?> / <?= htmlspecialchars($row['total_questions']) ?> (<?= $percentage ?>%)
                </span>
              </div>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
