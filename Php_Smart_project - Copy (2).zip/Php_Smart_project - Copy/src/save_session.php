<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Not logged in']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'No data received']);
    exit;
}

$conn = mysqli_connect('localhost', 'root', '', 'login_register');
if (!$conn) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$stmt = mysqli_prepare($conn, "INSERT INTO quiz_sessions 
    (user_id, start_time, end_time, duration_seconds, score, total_questions) 
    VALUES (?, ?, ?, ?, ?, ?)");

mysqli_stmt_bind_param($stmt, 'issiii', 
    $_SESSION['user_id'],
    $data['start_time'],
    $data['end_time'],
    $data['duration_seconds'],
    $data['score'],
    $data['total_questions']
);

mysqli_stmt_execute($stmt);

if (mysqli_stmt_affected_rows($stmt) > 0) {
    echo json_encode(['status' => 'ok']);
} else {
    echo json_encode(['status' => 'failed']);
}
