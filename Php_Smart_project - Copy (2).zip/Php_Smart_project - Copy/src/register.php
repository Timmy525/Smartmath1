<?php
// register.php

$errors = [];

if (isset($_POST['submit'])) {
    // Sanitize input
    $full_name = trim($_POST['fullname'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $password  = $_POST['password'] ?? '';

    // Basic validation
    if ($full_name === '' || $username === '' || $password === '') {
        $errors[] = 'All fields are required.';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 8 characters long.';
    }

    if (!$errors) {
        // Secure connection
        $conn = mysqli_connect('localhost', 'root', '', 'login_register');
        if (!$conn) {
            $errors[] = 'Could not connect to the database.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $sql  = "INSERT INTO users (fullname, username, password) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);

            if ($stmt) {
                mysqli_stmt_bind_param($stmt, 'sss', $full_name, $username, $hash);
                if (mysqli_stmt_execute($stmt)) {
                    // Redirect silently
                    header('Location: Login.php');
                    exit;
                } else {
                    $errors[] = 'Registration failed. Please try again.';
                }
                mysqli_stmt_close($stmt);
            } else {
                $errors[] = 'Server error. Please try again later.';
            }
            mysqli_close($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SMART App — Register</title>
  <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">

  <div class="flex w-full max-w-6xl shadow-lg bg-white rounded-lg overflow-hidden">

    <!-- Left Column – Registration Form -->
    <div class="w-full md:w-1/2 p-8">
      <nav class="flex items-center justify-between mb-8">
        <div class="flex items-center space-x-2">
          <img src="photo6.JPG" alt="Logo" class="w-10 h-10 rounded-full">
          <span class="text-xl font-bold text-blue-600">SMART MATH</span>
        </div>
      </nav>

      <h1 class="text-2xl font-bold mb-6">Register Here</h1>

      <?php if ($errors): ?>
        <div class="mb-4 p-2 bg-red-100 text-red-700 rounded">
          <ul>
            <?php foreach ($errors as $e): ?>
              <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form action="register.php" method="POST">
        <div class="mb-4">
          <label for="fullname" class="block text-gray-700">Full Name</label>
          <input
            type="text" id="fullname" name="fullname"
            value="<?= isset($_POST['fullname']) ? htmlspecialchars($_POST['fullname']) : '' ?>"
            placeholder="Enter Full Name"
            class="w-full mt-1 p-2 border rounded-md focus:outline-none focus:ring focus:border-blue-500"
          >
        </div>

        <div class="mb-4">
          <label for="username" class="block text-gray-700">Username</label>
          <input
            type="text" id="username" name="username"
            value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>"
            placeholder="Enter Username"
            class="w-full mt-1 p-2 border rounded-md focus:outline-none focus:ring focus:border-blue-500"
          >
        </div>

        <div class="mb-4">
          <label for="password" class="block text-gray-700">Password</label>
          <input
            type="password" id="password" name="password"
            placeholder="Enter Password"
            class="w-full mt-1 p-2 border rounded-md focus:outline-none focus:ring focus:border-blue-500"
          >
        </div>

        <button
          type="submit" name="submit"
          class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
        >
          Register
        </button>
      </form>

      <p class="text-sm mt-4 text-gray-600">
        Already have an account?
        <a href="Login.php" class="text-blue-600 hover:underline">Log in here</a>.
      </p>
    </div>

    <!-- Right Column – Welcome Message -->
    <div class="hidden md:flex w-1/2 bg-blue-600 text-white items-center justify-center p-8">
      <div class="text-center">
        <h2 class="text-3xl font-bold mb-4">Welcome</h2>
        <p class="text-lg">
          Create an account to access your dashboard, track progress, and manage
          your preferences.
        </p>
      </div>
    </div>

  </div>
</body>
</html>
