<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: Login.php');
    exit;
}

$conn = mysqli_connect('localhost', 'root', '', 'login_register');
$user_id = $_SESSION['user_id'];
$sql = "SELECT question, user_answer, correct_answer, is_correct, created_at 
        FROM quiz_results WHERE user_id = ? ORDER BY created_at DESC LIMIT 10";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Your Quiz Results</title>
  <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
<div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-3xl">
  <h2 class="text-2xl font-bold mb-6 text-blue-600">Recent Quiz Results</h2>
  <table class="w-full table-auto border-collapse">
    <thead>
      <tr class="bg-blue-100">
        <th class="border px-4 py-2">Question</th>
        <th class="border px-4 py-2">Your Answer</th>
        <th class="border px-4 py-2">Correct</th>
        <th class="border px-4 py-2">Result</th>
        <th class="border px-4 py-2">Date</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = mysqli_fetch_assoc($result)) : ?>
        <tr class="text-center">
          <td class="border px-4 py-2"><?= htmlspecialchars($row['question']) ?></td>
          <td class="border px-4 py-2"><?= $row['user_answer'] ?></td>
          <td class="border px-4 py-2"><?= $row['correct_answer'] ?></td>
          <td class="border px-4 py-2">
            <?= $row['is_correct'] ? '<span class="text-green-600">✔</span>' : '<span class="text-red-600">✘</span>' ?>
          </td>
          <td class="border px-4 py-2"><?= $row['created_at'] ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body>
</html>
