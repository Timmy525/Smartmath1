<?php
session_start();

$error = '';

if (isset($_POST['login'])) {
    // Sanitize input
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Both username and password are required.';
    } else {
        // Connect to database
        $conn = mysqli_connect('localhost', 'root', '', 'login_register');
        if (!$conn) {
            $error = 'Database connection failed.';
        } else {
            // Query user data securely
            $stmt = mysqli_prepare($conn, "SELECT id, password FROM users WHERE username = ?");
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);

            if (mysqli_stmt_num_rows($stmt) === 1) {
                mysqli_stmt_bind_result($stmt, $userId, $hashedPassword);
                mysqli_stmt_fetch($stmt);

                if (password_verify($password, $hashedPassword)) {
                    // ✅ Store session
                    $_SESSION['user_id'] = $userId;
                    header('Location: index1.php');
                    exit;
                } else {
                    $error = 'Invalid username or password.';
                }
            } else {
                $error = 'Invalid username or password.';
            }

            mysqli_stmt_close($stmt);
            mysqli_close($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SMART App — Login</title>
  <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
  <div class="flex w-full max-w-6xl shadow-lg bg-white rounded-lg overflow-hidden">

    <!-- Left Column - Login Form -->
    <div class="w-full md:w-1/2 p-8">
      <nav class="flex items-center justify-between mb-8">
        <div class="flex items-center space-x-2">
          <img src="photo6.JPG" alt="Logo" class="w-10 h-10 rounded-full">
          <span class="text-xl font-bold text-blue-600">SMART MATH</span>
        </div>
      </nav>

      <h1 class="text-2xl font-bold mb-6">Login Here</h1>

      <?php if ($error): ?>
        <div class="mb-4 p-2 bg-red-100 text-red-700 rounded">
          <?= htmlspecialchars($error); ?>
        </div>
      <?php endif; ?>

      <form action="Login.php" method="POST">
        <div class="mb-4">
          <label for="username" class="block text-gray-700 font-medium mb-2">Username</label>
          <input type="text" id="username" name="username" required
                 class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-6">
          <label for="password" class="block text-gray-700 font-medium mb-2">Password</label>
          <input type="password" id="password" name="password" required
                 class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <button type="submit" name="login"
                class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition">
          Login
        </button>
      </form>

      <p class="text-sm mt-4 text-gray-600">
        Don't have an account?
        <a href="register.php" class="text-blue-600 hover:underline">Create one here</a>.
      </p>
    </div>

    <!-- Right Column - Welcome Message -->
    <div class="hidden md:flex w-1/2 bg-blue-600 text-white items-center justify-center p-8">
      <div class="text-center">
        <h2 class="text-3xl font-bold mb-4">Welcome</h2>
        <p class="text-lg">Log in to access your dashboard, view your account details, and manage your preferences.</p>
      </div>
    </div>

  </div>
</body>
</html>
