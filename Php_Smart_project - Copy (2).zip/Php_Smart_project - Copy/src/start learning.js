// Full updated JS code with score tracking, timer, and session saving

const questions = [
  { text: "What is 5 + 2?", answer: 7, solution: "5 + 2 = 7" },
  { text: "What is 7 - 2?", answer: 5, solution: "7 - 2 = 5" },
  { text: "What is 0 + 4?", answer: 4, solution: "0 + 4 = 4" },
  { text: "What is 1 - 1?", answer: 0, solution: "1 - 1 = 0" },
  { text: "What is 1 + 1?", answer: 2, solution: "1 + 1 = 2" }
];

let current = 0;
let correctAnswers = 0;
let startTime, endTime;
let userAnswers = [];

const examplePage = document.getElementById('examplePage');
const questionPage = document.getElementById('questionPage');
const questionBox = document.getElementById('question');
const answerInput = document.getElementById('answer');
const resultBox = document.getElementById('result');
const solutionBox = document.getElementById('solution');
const nextBtn = document.getElementById('nextBtn');

function showQuestion() {
  questionBox.textContent = `Question ${current + 1}: ${questions[current].text}`;
  answerInput.value = '';
  resultBox.textContent = '';
  solutionBox.textContent = '';
  nextBtn.classList.add('hidden');
}

document.getElementById('startBtn').onclick = function () {
  examplePage.classList.add('hidden');
  questionPage.classList.remove('hidden');
  current = 0;
  correctAnswers = 0;
  userAnswers = [];
  startTime = new Date();
  showQuestion();
  document.getElementById('answerForm').classList.remove('hidden');
};

document.getElementById('prevBtn').onclick = function () {
  questionPage.classList.add('hidden');
  examplePage.classList.remove('hidden');
};

document.getElementById('answerForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const userAnswer = Number(answerInput.value);
  const correctAnswer = questions[current].answer;
  userAnswers.push(userAnswer);

  // Save individual question result to DB
  fetch('save_result.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      question: questions[current].text,
      user_answer: userAnswer,
      correct_answer: correctAnswer
    })
  });

  if (userAnswer === correctAnswer) {
    resultBox.textContent = "🎉 Correct! Good job!";
    resultBox.classList.remove("text-red-600");
    resultBox.classList.add("text-green-600");
    correctAnswers++;
    solutionBox.textContent = '';
  } else {
    resultBox.textContent = "Oops! Try again.";
    resultBox.classList.remove("text-green-600");
    resultBox.classList.add("text-red-600");
    solutionBox.textContent = questions[current].solution;
  }

  nextBtn.classList.remove('hidden');
});

document.getElementById('nextBtn').addEventListener('click', function () {
  current++;
  if (current < questions.length) {
    showQuestion();
  } else {
    document.getElementById('answerForm').classList.add('hidden');
    nextBtn.classList.add('hidden');
    resultBox.textContent = "🎉 You finished all the questions!";
    resultBox.classList.remove("text-red-600");
    resultBox.classList.add("text-green-600");
    solutionBox.textContent = '';
    questionBox.textContent = "Well done!";

    // Finish timing and save session
    endTime = new Date();
    const duration = Math.floor((endTime - startTime) / 1000);

    fetch('save_session.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        score: correctAnswers,
        total_questions: questions.length,
        start_time: startTime.toISOString(),
        end_time: endTime.toISOString(),
        duration_seconds: duration
      })
    });
  }
});
