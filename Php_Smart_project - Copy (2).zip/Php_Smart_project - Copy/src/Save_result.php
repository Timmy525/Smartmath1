<?php
session_start();

// Set response header for JSON
header('Content-Type: application/json');

// ✅ DEBUG (Uncomment this line to test session during development)
// var_dump($_SESSION); exit;

// ✅ Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized - no session']);
    exit;
}

// ✅ Decode the incoming JSON payload
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['question'], $data['user_answer'], $data['correct_answer'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid input data']);
    exit;
}

// ✅ Connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'login_register');
if (!$conn) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// ✅ Prepare values
$user_id       = $_SESSION['user_id'];
$question      = mysqli_real_escape_string($conn, $data['question']);
$user_answer   = (int)$data['user_answer'];
$correct_answer = (int)$data['correct_answer'];
$is_correct    = ($user_answer === $correct_answer) ? 1 : 0;

// ✅ Insert into the database
$sql = "INSERT INTO quiz_results (user_id, question, user_answer, correct_answer, is_correct)
        VALUES (?, ?, ?, ?, ?)";

$stmt = mysqli_prepare($conn, $sql);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, 'isiii', $user_id, $question, $user_answer, $correct_answer, $is_correct);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    echo json_encode(['status' => 'ok']);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Query preparation failed']);
}

mysqli_close($conn);
?>
