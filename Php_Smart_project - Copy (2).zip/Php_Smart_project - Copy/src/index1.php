<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: Login.php');
    exit;
}

// Fetch user data
$conn = mysqli_connect('localhost', 'root', '', 'login_register');
if (!$conn) {
    die('Database connection failed.');
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT fullname, username FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $fullname, $username);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
<!doctype html>
<html lang="en" x-data="{ profileOpen: false }">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smart Math Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
  <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Navbar -->
<nav class="bg-blue-500 shadow">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between items-center h-16">

      <!-- Logo -->
      <div class="flex items-center space-x-2">
        <img src="photo6.JPG" alt="Logo" class="w-10 h-10 rounded-full" />
        <span class="text-2xl font-bold text-white">SMART MATH</span>
      </div>

      <!-- Navigation and Profile -->
      <div class="flex items-center space-x-6">

        <!-- Navigation Links -->
        <a href="index.php" class="text-white hover:text-gray-200 font-semibold">Home</a>
        <a href="about.html" class="text-white hover:text-gray-200 font-semibold">About Us</a>
        <a href="contact.html" class="text-white hover:text-gray-200 font-semibold">Contact Us</a>

        <!-- Profile Dropdown -->
        <div class="relative" @click.away="profileOpen = false">
          <button @click="profileOpen = !profileOpen" class="flex items-center focus:outline-none">
            <img src="emoji2.jpeg" class="w-10 h-10 rounded-full  border-white mr-2" alt="User" />
            <span class="text-white font-medium hidden md:inline"><?= htmlspecialchars($fullname) ?></span>
            <svg class="ml-1 w-4 h-4 fill-current text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
              <path d="M5.25 7.5l4.75 5 4.75-5z" />
            </svg>
          </button>

          <!-- Dropdown Menu -->
          <div x-show="profileOpen" x-transition class="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg z-50">
            <div class="px-4 py-3 text-sm text-gray-800 border-b">
              <div class="font-semibold"><?= htmlspecialchars($fullname) ?></div>
              <div class="text-xs text-gray-500"><?= htmlspecialchars($username) ?></div>
            </div>
            <a href="profile.php" class="block px-4 py-2 text-sm text-blue-600 hover:bg-gray-100">View Profile</a>
            <a href="logout.php" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="bg-white py-16 px-6 text-center shadow">
  <div class="max-w-4xl mx-auto">
    <h1 class="text-4xl font-bold text-blue-500 mb-4">Master Mathematics with Interactive Quizzes</h1>
    <p class="text-lg text-gray-600 mb-6">
       Take challenging math quizzes, and track your progress as you improve your mathematical skills.
    </p>
  </div>
</section>

<!-- Features Section -->
<section class="py-16 px-6 bg-gray-100">
  <div class="max-w-5xl mx-auto grid md:grid-cols-2 gap-10 text-center">
    <!-- <a href="topics.html">
      <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition">
        <h2 class="text-xl font-semibold text-blue-600 mb-2">Topic</h2>
        <p class="text-gray-600">Passing through different Topics </p>
      </div>
    </a> -->

    <a href="Start learning.html">
      <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition">
        <h2 class="text-xl font-semibold text-blue-600 mb-2">Start Learning</h2>
        <p class="text-gray-600">Challenge yourself with various math topics and difficulty levels</p>
      </div>
    </a>

      <a href="session_results.php">
    <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition">
      <h2 class="text-xl font-semibold text-blue-600 mb-2">Track Progress</h2>
      <p class="text-gray-600">Monitor your improvement and earn achievements</p>
    </div>
    </a>
  </div>
</section>

<!-- Call to Action -->
<section class="bg-blue-500 text-white py-16 px-6 text-center">
  <div class="max-w-3xl mx-auto">
    <h2 class="text-3xl font-bold mb-4">Ready to Start Learning?</h2>
    <p class="mb-6 text-lg">Join thousands of students improving their math skills every day.</p>
  </div>
</section>

<!-- Footer -->
<footer class="bg-gray-800 text-white py-8">
  <div class="max-w-6xl mx-auto px-4 md:flex md:justify-between">
    <div class="mb-6 md:mb-0">
      <h2 class="text-2xl font-bold text-blue-400">Smart Math</h2>
      <p class="text-sm text-gray-400 mt-2">Empowering learners through interactive math quizzes and progress tracking.</p>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-3 gap-6 text-sm">
      <div>
        <h3 class="font-semibold mb-2 text-gray-200">Pages</h3>
        <ul class="space-y-1">
          <li><a href="index.html" class="hover:underline text-gray-400">Home</a></li>
          <li><a href="about.html" class="hover:underline text-gray-400">About</a></li>
          <li><a href="contact.html" class="hover:underline text-gray-400">Contact Us</a></li>
        </ul>
      </div>
    </div>
  </div>

  <div class="mt-8 border-t border-gray-700 pt-4 text-center text-sm text-gray-400">
    &copy; 2025 Smart Math. All rights reserved.
  </div>
</footer>

</body>
</html>
